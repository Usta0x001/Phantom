"""Phantom output formatters package."""
